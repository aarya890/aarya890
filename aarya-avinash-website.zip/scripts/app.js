// scripts/app.js
console.log("Website loaded successfully.");
